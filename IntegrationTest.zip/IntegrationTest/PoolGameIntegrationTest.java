package IntegrationTest;

import org.junit.jupiter.api.Test;
import java.awt.*;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class PoolGameIntegrationTest 
{
    @Test
    public void testBallMovement() 
    {
        ball testBall = new ball(100, 100, 5, 5, Color.RED, 1, false);

        testBall.move();

        assertEquals(105, testBall.x, 0.01);
        assertEquals(105, testBall.y, 0.01);

        testBall.move();
        assertTrue(testBall.vx < 5);
        assertTrue(testBall.vy < 5);
    }

    @Test
    public void testBallWallCollision() 
    {
        ball testBall = new ball(basePhysics.SCREEN_WIDTH - basePhysics.BALL_RADIUS - 1, 100, 5, 0, Color.BLUE, 2, true);

        testBall.move();
        testBall.checkWallCollision();

        assertTrue(testBall.vx < 0);
    }

    @Test
    public void testBallPocketCollision() 
    {
        ball testBall = new ball(10, 10, 0, 0, Color.YELLOW, 3, false);
        List<Point> pockets = List.of(new Point(10, 10));

        testBall.checkPocketCollision(pockets);

        assertTrue(testBall.inPocket);
        assertEquals(0, testBall.vx);
        assertEquals(0, testBall.vy);
    }

    @Test
    public void testTurnManagerSwitchTurn() 
    {
        basePhysics poolGame = new basePhysics();
        TurnManager turnManager = new TurnManager();

        poolGame.setPlayerOneTurnFinished(false);
        turnManager.checkTurn(poolGame);

        assertFalse(turnManager.isPlayerOneTurn());
        assertTrue(turnManager.isPlayerTwoTurn());
    }

    @Test
    public void testTurnManagerPocketedBall() 
    {
        basePhysics poolGame = new basePhysics();
        TurnManager turnManager = new TurnManager();
        List<ball> balls = poolGame.getBalls();

        ball solidBall = balls.stream().filter(b -> !b.isStriped && b.number != 0).findFirst().orElse(null);
        assertNotNull(solidBall);
        solidBall.inPocket = true;

        turnManager.checkTurn(poolGame);

        assertTrue(turnManager.isPlayerOneTurn());
    }

    @Test
    public void testGameOverCondition() 
    {
        basePhysics poolGame = new basePhysics();
        TurnManager turnManager = new TurnManager();

        List<ball> balls = poolGame.getBalls();
        balls.stream().filter(b -> !b.isStriped && b.number != 0).forEach(b -> b.inPocket = true);

        turnManager.checkTurn(poolGame);

        assertTrue(poolGame.isPlayerOneTurnFinished() || poolGame.isPlayerTwoTurnFinished());
    }
}
