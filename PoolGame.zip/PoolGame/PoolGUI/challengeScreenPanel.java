package PoolGUI;

import javax.swing.*;
import java.awt.*;

public class challengeScreenPanel extends JPanel
{
    public challengeScreenPanel() 
    {
        this.setBackground(Color.BLUE); // Set background color to blue

        // Add a label to indicate this screen.
        JLabel label = new JLabel("Challenge Accepted!", JLabel.CENTER);
        label.setForeground(Color.WHITE); // Optional: Adjust text color for readability
        label.setFont(new Font("Arial", Font.BOLD, 16));

        // Set layout and add components.
        this.setLayout(new BorderLayout());
        this.add(label, BorderLayout.CENTER);
    }
}