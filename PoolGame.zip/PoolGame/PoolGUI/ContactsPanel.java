package PoolGUI;

import java.awt.*;
import javax.swing.*;

public class ContactsPanel extends JPanel
{
  //private CardLayout cardLayout;
  private JPanel container;
  // Constructor for the contacts panel.
  public ContactsPanel()
  {
    //this.cardLayout = cardLayout;
    this.container = container;
	this.setBackground(Color.BLUE);
	
    // Create a list of example contacts.
    DefaultListModel<String> list = new DefaultListModel<String>();
    list.addElement("Player One");
    list.addElement("<html><b>Player Two</b></html>");
    list.addElement("Player Three");
    list.addElement("Player Four");

    // Use BorderLayout to lay out the components in this panel.
    this.setLayout(new BorderLayout());

    // Create the contacts list in the center.
    JList<String> contactList = new JList<>(list);
    contactList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    contactList.setLayoutOrientation(JList.VERTICAL);
    contactList.setVisibleRowCount(-1);
    contactList.setFont(contactList.getFont().deriveFont(Font.PLAIN, 16));
    contactList.setBackground(Color.WHITE);
    contactList.setForeground(Color.BLACK);
    contactList.setPreferredSize(new Dimension(300, 200));
    JPanel contactListBuffer = new JPanel();
    contactListBuffer.setBackground(Color.BLUE);
    contactListBuffer.add(new JScrollPane(contactList));
    this.add(contactListBuffer, BorderLayout.CENTER);
    
    // Create the contacts label in the north.
    JLabel label = new JLabel("Players Looking for a Game", JLabel.CENTER);
    label.setForeground(Color.WHITE);
    this.add(label, BorderLayout.NORTH);    

    // Create the buttons in the south.
    JPanel buttonsPanel = new JPanel(new GridLayout(2, 1));
    buttonsPanel.setBackground(Color.BLUE);
    
    JPanel contactButtons = new JPanel();
    contactButtons.setBackground(Color.BLUE);
    JButton challengeButton = new JButton("Challenge Player");
    JButton acceptButton = new JButton("Accept Challenge");
    acceptButton.addActionListener(e -> {
        Component[] components = container.getComponents();
        for (Component comp : components) {
            if (comp instanceof challengeScreenPanel) {
                comp.setVisible(true); 
            } else {
                comp.setVisible(false);
            }
        }
    });
    contactButtons.add(challengeButton);
    contactButtons.add(acceptButton);
    
    JPanel logoutButtonPanel = new JPanel();
    logoutButtonPanel.setBackground(Color.BLUE);
    JButton logoutButton = new JButton("Log Out");
    logoutButton.addActionListener(e -> {
        if (container != null) {
            System.out.println("Logging out");
           
            CardLayout layout = (CardLayout) container.getLayout();
            layout.show(container, "2"); 
        } else {
            System.err.println("Container is not initialized. Cannot log out.");
        }
    });
    logoutButtonPanel.add(logoutButton);

    buttonsPanel.add(contactButtons);
    buttonsPanel.add(logoutButtonPanel);
    this.add(buttonsPanel, BorderLayout.SOUTH);
}
}
