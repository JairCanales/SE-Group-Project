package PoolGUI;

import javax.swing.*;
import java.awt.*;

public class PoolGamePanel extends JPanel {
    public PoolGamePanel() {
        setLayout(new BorderLayout());

        // Create the pool game instance
        basePhysics poolGame = new basePhysics();
        poolGame.setPreferredSize(new Dimension(basePhysics.SCREEN_WIDTH, basePhysics.SCREEN_HEIGHT));

        // Add the pool game to this panel
        this.add(poolGame, BorderLayout.CENTER);
    }
    
    public void maximizeWindow()
    {
        SwingUtilities.invokeLater(() -> {
            JFrame topFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
            if (topFrame != null) {
                topFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
            }
        });
    }
}