package UnitTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import java.io.*;
import org.junit.*;
import java.sql.*;
import java.util.*;
import java.sql.Connection;

public class TestDatabaseServer
{
  private Database database;
  private final String dbPropertiesFile = "PoolGUI/db.properties";
  
  @Before
  public void setUp()
  {
      database = new Database();
      database.setConnection(dbPropertiesFile);
  }

  @After
  public void tearDown() throws SQLException 
  {
      Connection conn = database.getConnection();
      if (conn != null && !conn.isClosed()) 
      {
          String deleteQuery = "DELETE FROM users WHERE username = 'testuser@example.com'";
          Statement statement = conn.createStatement();
          statement.execute(deleteQuery);
          conn.close();
      }
  }

  @Test
  public void testSetConnection()
  {
      Connection conn = database.getConnection();
      assertNotNull("Connection should not be null after setConnection", conn);
  }

  @Test
  public void testQuery()
  {
      String query = "SELECT AES_DECRYPT(password, 'key') AS password FROM users WHERE username = 'jsmith@uca.edu'";
      ArrayList<String> result = database.query(query);
      assertNotNull("Result should not be null", result);
      assertEquals("hello123", result.get(0).split(",")[0]);
  }

  @Test
  public void testExecuteDML() 
  {
	  String insertQuery = "INSERT INTO users (username, password) VALUES ('testuser@example.com', AES_ENCRYPT('testpassword', 'key'))";
      try 
      {
          database.executeDML(insertQuery);

          String verifyQuery = "SELECT AES_DECRYPT(password, 'key') AS password FROM users WHERE username = 'testuser@example.com'";
          ArrayList<String> result = database.query(verifyQuery);
          assertNotNull("Result should not be null after DML execution", result);
          assertEquals("testpassword", result.get(0).split(",")[0]);

      } catch (SQLException e) {
          fail("SQLException should not occur: " + e.getMessage());
      }
  }
}
