package UnitTest;

import java.sql.*;
import java.io.*;
import java.util.*;

public class Database
{
  private Connection conn;
  //Add any other data fields you like – at least a Connection object is mandatory
  
  public Database()
  {
    try
    {
    	//Create a properties object
    	Properties props = new Properties();
    	
    	//Open a FileInputStream
    	FileInputStream fis = new FileInputStream("PoolGUI/db.properties");
    	props.load(fis);
    	
    	String url = props.getProperty("url");
    	String user = props.getProperty("user");
    	String pass = props.getProperty("password");
    	
    	//Set the connection
    	conn = DriverManager.getConnection(url, user, pass);
    }
    catch (Exception e)
    {
    	e.printStackTrace();
    }
  }
  
  public ArrayList<String> query(String query)
  {
    //Variable declaration/initialization
	ArrayList<String> list = new ArrayList<String>();
	int noColumns = 0;
	
	try
	{
		//Create db statement
		Statement statement = conn.createStatement();
		
		//Get the ResultSet
		ResultSet rs = statement.executeQuery(query);
		
		//Get the ResultSetMetaData (# of columns)
		ResultSetMetaData rmd = rs.getMetaData();
		
		//Get the # of columns
		noColumns = rmd.getColumnCount();
		
		while(rs.next())
		{
			String record = "";
			
			//Iterate thru each field
			for(int i = 0; i < noColumns; i++)
			{
				record += rs.getString(i+1);
				record += ",";
			}
			list.add(record);
		}
		//Check for empty list
		if (list.size() == 0)
		{
			return null;
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
		return null;
	}
	return list;
  }
  
  public void executeDML(String dml) throws SQLException
  {
	  Statement statement = conn.createStatement();
	  statement.execute(dml);
  } 
  
  public boolean verifyAccount(String username, String password)
  {
	  String command = "select * from user where username='" + username + "' and password='" + password + "';";
	  
	  ArrayList<String> result = query(command);
	  
	  if(result != null)
	  {
		  return true;
	  }
	  else
	  {
		  return false;
	  }
  }
  
  public boolean createNewAccount(String username, String password)
  {
	  String command = "SELECT * FROM user WHERE username='" + username + "';";
	  
	  ArrayList<String> result = query(command);
	  
	  if(result != null)
	  {
		  return false;
	  }
	  
	  else
	  {
		  String newUser = "INSERT INTO user VALUES('" + username + "', '" + password + "')";
		  try
		  {
			  executeDML(newUser);
		  }
		  catch(SQLException e)
		  {
			  e.printStackTrace();
		  }
		  
		  return true;
	  }
  }

  public void setConnection(String fn)
  {
    try
    {
    	//Create a properties object
    	Properties props = new Properties();
    	
    	//Open a FileInputStream
    	FileInputStream fis = new FileInputStream(fn);
    	props.load(fis);
    	
    	String url = props.getProperty("url");
    	String user = props.getProperty("user");
    	String pass = props.getProperty("password");
    	
    	//Set the connection
    	conn = DriverManager.getConnection(url, user, pass);
    }
    catch (Exception e)
    {
    	e.printStackTrace();
    }
  }
  
  public Connection getConnection()
  {
	  return conn;
  }
}
